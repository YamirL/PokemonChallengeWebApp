import React from 'react';
import convert from 'convert-units';
import './styles.css';
import * as util from '../../../services/util';

const Pokemon = ({ data }) => {

    const getProp = (name, value) => (
        <div>
            <span><b>{name}</b></span><br></br>
            <span>{value}</span>
        </div >
    );

    const transformData = (data) => {
        /* Height */
        const height_m = data.height / 10; // to meters
        let height_ft = convert(height_m).from("m").to("ft"); // to foot
        let height_in = convert(height_ft - Math.trunc(height_ft)).from("ft").to("in"); // inches
        height_in = Math.round(height_in);
        height_ft = Math.trunc(height_ft);

        /* weight */
        const weight_km = data.weight / 10; // to kg
        const weight_lb = Math.round(convert(weight_km).from('kg').to('lb') * 10) / 10; // to lbs

        const info = {
            height: `${height_m} m (${height_ft}'${height_in}")`,
            weight: `${weight_km} kg (${weight_lb} lbs)`,
            url: `https://img.pokemondb.net/artwork/${data.name}.jpg`,
            title: `${util.capitalize(data.name)} #${('000' + data.id).slice(-3)}`,
            name: data.name,
        }

        console.log(info);
        return info;
    }

    const getPokemon = (data) => {
        const pokeInfo = transformData(data);
        return (
            <div>
                <div className="header-title">
                    <h3>{pokeInfo.title}</h3>
                </div>
                <div className="pokemon-pic">
                    <img src={pokeInfo.url} alt={pokeInfo.name}></img>
                </div>

                <div className="container-general-info">
                    {getProp("Height", pokeInfo.height)}
                    {getProp("Weight", pokeInfo.weight)}
                    {getProp("Ability", data.ability)}

                </div>
            </div>
        );
    }
    return (
        <div>
            {data ? getPokemon(data) : null}
        </div>
    );
}

export default Pokemon;