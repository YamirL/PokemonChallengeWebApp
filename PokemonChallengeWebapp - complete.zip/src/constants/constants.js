export const API_BASE_URL = "http://demo-javaapp.tfxajisrwg.us-east-2.elasticbeanstalk.com/services"
export const API_BATTLES = `${API_BASE_URL}/battles/getAll`
export const API_POKEMON = `${API_BASE_URL}/pokedex/pokemon`
 //*/
/*export const API_BASE_URL = "http://localhost:8082/PokemonArena/services"
export const API_BATTLES = `${API_BASE_URL}/battles/getAll` //*/
